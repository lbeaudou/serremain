import { Meteor } from 'meteor/meteor';

data = new Mongo.Collection('data');
dbstatus = new Mongo.Collection('status');
commande = new Mongo.Collection('commande');
serre = new Mongo.Collection('serre');
img = new Mongo.Collection('img');
sensordata = new Mongo.Collection('sensordata');
Meteor.startup(() => {
	serre.insert({"serre": "esp32_0C6E78", date: new Date()});
 var mqtt = require('mqtt'); 

var client = mqtt.connect('mqtt://broker.mqttdashboard.com:1883');

client.subscribe('serre/#'); 

client.on('message', Meteor.bindEnvironment(function (topic, message, f) {  
if(topic.includes('serre/cp/')) {
// Meteor.call('insert', topic.toString(), message.toString());
topic = topic.toString();
message = message.toString();

topic = topic.replace('serre/cp/', '');
t = topic.split('/');
serre = t[0];
type = t[1];
	 data.insert({date:new Date(), serre, type, message});
	 db = dbstatus.findOne({device: serre});

console.log(message.toString())
}
console.log(topic);
if(topic.includes('serre/status/')) {
	m = JSON.parse(message);
	console.log(m)
doc = dbstatus.findOne({device:m.device});

doc ? dbstatus.update({device: m.device}, {$set: {"km_1":m.km_1,"km_2":m.km_2,"km_3":m.km_3,"km_4":m.km_4}})  : dbstatus.insert(m);
}

if(topic.includes('serre/img/')) {
	topic = topic.replace('serre/img/', '');
t = topic.split('/');
serre = t[0];
doc = dbstatus.findOne({device:serre});

doc ? dbstatus.update({device: serre}, {$set: {"img":message.toString(), date: new Date()}})  : dbstatus.insert({"device":serre, "img":message.toString()});
img.insert({device:serre, "img":message.toString(), date: new Date()});
}

if(topic.includes('serre/sensor/')) {
	topic = topic.replace('serre/sensor/', '');
t = topic.split('/');
serre = t[0];
message = JSON.parse(message);
message.date = new Date();
sensordata.insert(message);
}

}));


Meteor.methods({
  'insert':function(topic, message) {

	
  },'km':function(km, val) {
	topic = 'serre/km/omega/' + km;
	 client.publish(topic, val); 
	
  },
  'addeventkm' : function(data) {
	 return  commande.insert(data);
	  
  }, 'removeeventkm': function(data) {
	return commande.remove(data);
  },
  'uptageeventkm': function(c, heure, dure) {
	  commande.update(c, {$set : { heure, dure}});
	  
	  
  },
"addserre": function(id, nom) {
	console.log(this.userId);
	ser = serre.findOne({serre: id});
	console.log(ser);
		if(ser) {
	return Meteor.users.update(this.userId, { $push: { "profile.serre" : {"_id":id,nom}}});
		} else {
			return 0;
		}
	
	

},
"removeserre": function(id, nom) {
	console.log(this.userId);
	return Meteor.users.update(this.userId, { $pull: { "profile.serre" : {"_id":id,nom}}});

},
"updateserre": function(id, nom, newv) {
	console.log(this.userId);
	
	Meteor.users.update(this.userId, { $pull: { "profile.serre" : {"_id":id,nom}}});
	
	return Meteor.users.update(this.userId, { $push: { "profile.serre" : {"_id":id,"nom":newv}}});

},
"updatekm": function(device, type, data) {
	dbstatus.update({device}, { $pull: { events :{ type }}});
	dbstatus.update({device}, { $push: { events : data }})
	send = dbstatus.findOne({device})
	client.publish('serre/event/omega', JSON.stringify(send["events"])); 
}
	
	
	
	 
	
})

});




	

Meteor.publish('data', function(serre) {
	return data.find({serre}, {sort: {date: -1}, limit: 100});
});

Meteor.publish('status', function() {
	return dbstatus.find();
});

Meteor.publish('command', function() {
	return commande.find();
});

Meteor.publish('serre', function() {
	return serre.find();
});

Meteor.publish('img', function(device) {
	return img.find({device}, {sort: {date: -1}, limit: 8});
});

Meteor.publish('sensordata', function(device) {
	return sensordata.find({device}, {sort: {date: -1}, limit: 100});
});